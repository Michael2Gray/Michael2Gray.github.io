var gulp = require('gulp'),
	uglify = require('gulp-uglify'), //Minify JavaScript
	minifyCss = require('gulp-minify-css'), //Minify CSS
	imageMin = require('gulp-imagemin'), //Minify Images
	prefix = require('gulp-autoprefixer'), //Prefix CSS (Older Versions of Browsers)
	jsonminify = require('gulp-jsonminify'); //Minify JSON
 
var browserSync = require('browser-sync').create(); //Reload the Browser
var reload = browserSync.reload; //Reload the Browser

//Error Function
function errorLog(error){
	console.error.bind(error);
	this.emit('end');
}

//Scripts
gulp.task('scripts', function(){
	gulp.src('js/*.js')
		.pipe(uglify())
		.on('error', errorLog)
		.pipe(gulp.dest('build/js'))
		.pipe(reload({stream:true}));
});

//Styles
gulp.task('styles', function(){
	gulp.src('css/*.css')
		.pipe(minifyCss())
		.on('error', errorLog)
		.pipe(prefix('last 2 versions'))
		.pipe(gulp.dest('build/css'))
		.pipe(reload({stream:true}));
});

//Images
gulp.task('images', function(){
	gulp.src('img/*')
		.pipe(imageMin())
		.pipe(gulp.dest('build/img'));
		.pipe(reload({stream:true}));
});

gulp.task('images', function(){
	gulp.src('img/projects/*')
		.pipe(imageMin())
		.pipe(gulp.dest('build/img/projects'));
		.pipe(reload({stream:true}));
});

gulp.task('json', function () {
    gulp.src('json/*.json')
    	.pipe(jsonminify())
    	.pipe(gulp.dest('build/json'));
    	.pipe(reload({stream:true}));
});

//Watch
gulp.task('watch', function(){

	browserSync.init({
        server: {
        	baseDir: "./"
        }
    });

	gulp.watch('js/*.js', ['scripts']);
	gulp.watch('css/*.css', ['styles']);
	gulp.watch('img/*', ['images']);
	gulp.watch('/*.json', ['json']);

	gulp.watch('./*.html').on('change', reload);
});

gulp.task('default', ['scripts', 'styles', 'images', 'json', 'watch']);